// Import the functions you need from the SDKs you need
import { getAnalytics } from "firebase/analytics";
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth"; // Import Auth
import { getFirestore } from "firebase/firestore"; // Import Firestore

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDu7-8g4HekyJonpq44xU-OcS8uiYB9eVY",
  authDomain: "e-learning-ai.firebaseapp.com",
  projectId: "e-learning-ai",
  storageBucket: "e-learning-ai.appspot.com",
  messagingSenderId: "52227082781",
  appId: "1:52227082781:web:e1cd48b5d7b4db288754f4",
  measurementId: "G-RERJEGCQL9"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app); // Initialize analytics
const auth = getAuth(app); // Initialize Firebase Authentication
const db = getFirestore(app); // Initialize Firestore

// Export the initialized services
export { auth, db }; // Export auth and db
