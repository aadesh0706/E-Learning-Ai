import { doc, getDoc, setDoc } from "firebase/firestore";
import React, { useEffect, useState } from 'react';
import { auth, db } from '../firebase'; // Adjust the import path as needed

const Dashboard = () => {
  const [score, setScore] = useState(0);
  const user = auth.currentUser; // Get the currently logged-in user

  useEffect(() => {
    const fetchScore = async () => {
      if (user) {
        const docRef = doc(db, "users", user.uid);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          setScore(docSnap.data().score);
        } else {
          // If no score exists for the user, initialize it
          await setDoc(docRef, { score: 0 });
        }
      }
    };
    fetchScore();
  }, [user]);

  const handleAddPoints = async () => {
    const newScore = score + 10;
    setScore(newScore); // Update the score state

    if (user) {
      await setDoc(doc(db, "users", user.uid), { score: newScore });
    }
  };

  return (
    <div>
      <h2>Dashboard</h2>
      <p>Your Score: {score}</p>
      <button onClick={handleAddPoints}>Add 10 Points</button>
    </div>
  );
};

export default Dashboard;
