import React from 'react';
import { Link, Route, Routes } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import Login from './components/Login';
import Signup from './components/Signup';

const App = () => {
  return (
    <div>
      <h1>E-Learning AI</h1>
      <nav>
        <Link to="/login">
          <button>Login</button>
        </Link>
        <Link to="/signup">
          <button>Signup</button>
        </Link>
        <Link to="/dashboard">
          <button>Dashboard</button>
        </Link>
      </nav>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/" element={<h2>Welcome to the E-Learning Platform!</h2>} />
      </Routes>
    </div>
  );
};

export default App;